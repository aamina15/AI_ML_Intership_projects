# KGF 2 Movie Review Sentiment Analyzer

A Streamlit app version of the "Analyzing KGF 2 movie review with LLMs/GenAI" notebook.
Uses Hugging Face's `distilbert-base-uncased-finetuned-sst-2-english` model to classify
movie reviews as POSITIVE or NEGATIVE, with optional accuracy/F1 evaluation against
ground-truth labels.

## Repo structure

```
kgf2-sentiment-app/
├── app.py                      # Main Streamlit application
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── data/
│   └── sample_reviews.csv      # Sample dataset (semicolon-delimited)
└── .streamlit/
    └── config.toml             # Streamlit theme/server config
```

## Setup

1. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the app:
   ```bash
   streamlit run app.py
   ```

4. Open the URL Streamlit prints (usually `http://localhost:8501`).

## Features

- **Single Review mode**: type any review and get an instant sentiment prediction with confidence score.
- **Batch CSV Analysis mode**: upload a CSV with a `Review` column (and optional `Class` column
  with `POSITIVE`/`NEGATIVE` labels) to run sentiment analysis on the whole dataset, download results,
  and view accuracy/F1 metrics if ground truth is provided.

## Notes

- The first run will download the DistilBERT model (~260MB) from the Hugging Face Hub — this can
  take a minute depending on your connection.
- The CSV format follows the original notebook's dataset: semicolon (`;`) delimited, with `Review`
  and `Class` columns.
- If deploying to Streamlit Community Cloud, the `torch` CPU wheel will be installed automatically;
  no GPU is required for this model.
